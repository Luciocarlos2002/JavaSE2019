package ejercicios;

import java.util.Scanner;

public class Ejercicio33 {

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        System.out.println("Ingrese nro.");
        int n = leer.nextInt();
        int div = 0, sum = 0;
        for (int i = 1; i < n; i++) {
            if (n % i == 0) {
                sum += i;
            }
        }
        if (sum == n) {
            System.out.println("Es perfecto");
        } else {
            System.out.println("No es perfecto");
        }
        for (int j = 1; j <= n; j++) {
            if (n % j == 0) {
                div++;
            }

        }
        if (div == 2) {
            System.out.println("Es primo");
        } else {
            System.out.println("No es primo");
        }
    }
}
