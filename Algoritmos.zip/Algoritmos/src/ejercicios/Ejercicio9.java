package ejercicios;

import java.util.Scanner;
// Realizar un algoritmo que, dado un número entero, visualice en pantalla si es par o
// impar. En el caso de ser 0, debe visualizar “el número no es par ni impar
public class Ejercicio9 {

    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        int nro = leer.nextInt();
        if (nro % 2 == 0) {
            System.out.println("Es par");
        }else{
            System.out.println("Es impar");
        }
    }

}
